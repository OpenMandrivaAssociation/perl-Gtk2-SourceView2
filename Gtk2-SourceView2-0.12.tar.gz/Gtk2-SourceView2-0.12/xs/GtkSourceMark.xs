/*
 * Copyright (c) 2009-2010 by Emmanuel Rodriguez (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version; or the
 * Artistic License, version 2.0.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details; or the Artistic License.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, see
 * <https://www.gnu.org/licenses/>.
 */

#include "gtk2-sourceview2-perl.h"

MODULE = Gtk2::SourceView2::Mark PACKAGE = Gtk2::SourceView2::Mark PREFIX = gtk_source_mark_

GtkSourceMark*
gtk_source_mark_new (class, const gchar_ornull *name, const gchar *category)
	C_ARGS: name, category


const gchar*
gtk_source_mark_get_category (GtkSourceMark *mark)


GtkSourceMark_ornull*
gtk_source_mark_next (GtkSourceMark *mark, const gchar_ornull *category)


GtkSourceMark_ornull*
gtk_source_mark_prev (GtkSourceMark *mark, const gchar_ornull *category)
